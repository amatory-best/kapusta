import { useState } from 'react';

const documents = [
  {
    title: 'Закон о внесении изменений в закон о внесении изменений',
    number: '№ 420-З',
    date: '15.01.2026',
    size: '847 стр.',
    downloads: 3,
  },
  {
    title: 'О порядке заполнения формы справки о наличии справки об отсутствии судимости',
    number: '№ 228-П',
    date: '10.01.2026',
    size: '234 стр.',
    downloads: 1,
  },
  {
    title: 'Инструкция по применению инструкции по заполнению заявлений',
    number: '№ 1337-И',
    date: '05.01.2026',
    size: '1 247 стр.',
    downloads: 0,
  },
  {
    title: 'Постановление о создании комиссии по расследованию деятельности предыдущей комиссии',
    number: '№ 666-К',
    date: '01.01.2026',
    size: '56 стр.',
    downloads: 7,
  },
  {
    title: 'Методические рекомендации по правильному скреплению бумаг скрепкой (издание 14-е, дополненное)',
    number: '№ 007-МР',
    date: '25.12.2025',
    size: '342 стр.',
    downloads: 42,
  },
];

const faq = [
  {
    q: 'Как подать заявление?',
    a: 'Для подачи заявления вам необходимо: 1) Прийти лично 2) Взять талон 3) Дождаться своей очереди (2-4 часа) 4) Узнать, что нужен другой талон 5) Повторить с пункта 1. Заявление подаётся в 3-х экземплярах, заверенных нотариально, апостилированных и окроплённых святой водой.',
  },
  {
    q: 'Какие документы нужны для регистрации ИП?',
    a: 'Паспорт (оригинал + 47 копий), заявление (форма 1-ИП, 2-ИП, 3-ИП и запасная 3а-ИП), справка о несудимости, справка об отсутствии справок, фото 3x4 (с улыбкой запрещено), квитанция об оплате, квитанция об оплате квитанции, и справка о том, что вы действительно хотите это сделать.',
  },
  {
    q: 'Почему мне не перезвонили?',
    a: 'Ваш звонок очень важен для нас. Он записан, каталогизирован и бережно хранится в архиве. Перезвоним, как только закончится текущее совещание (ориентировочно — 2028 год).',
  },
  {
    q: 'Можно ли подать документы электронно?',
    a: 'Конечно! Вам нужно всего лишь: получить ЭЦП, зарегистрироваться на портале (он работает по чётным вторникам), загрузить скан документа в формате .bmp не более 200кб, подождать подтверждение по почте (обычной, не электронной), а затем принести оригиналы лично.',
  },
];

export default function DocumentsSection() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Documents */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">📄 Документы и нормативные акты</h2>
            <div className="space-y-3">
              {documents.map((doc, i) => (
                <div
                  key={i}
                  className="bg-gray-50 rounded-xl p-4 hover:bg-blue-50 transition-colors cursor-pointer group border border-gray-100"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl mt-1">
                      {i % 2 === 0 ? '📋' : '📑'}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm text-gray-900 group-hover:text-blue-800 transition-colors">
                        {doc.title}
                      </h4>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                        <span>{doc.number}</span>
                        <span>•</span>
                        <span>{doc.date}</span>
                        <span>•</span>
                        <span>{doc.size}</span>
                        <span>•</span>
                        <span>⬇️ {doc.downloads}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-400 mt-4 italic">
              * Документы представлены для ознакомления. За понимание их содержания министерство ответственности не несёт.
            </p>
          </div>

          {/* FAQ */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">❓ Часто задаваемые вопросы</h2>
            <p className="text-sm text-gray-500 mb-4">
              Ответы, которые не помогут, но создадут иллюзию заботы
            </p>
            <div className="space-y-3">
              {faq.map((item, i) => (
                <div
                  key={i}
                  className="border border-gray-200 rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-medium text-sm text-gray-900">{item.q}</span>
                    <span className={`text-xl transition-transform duration-300 ${openFaq === i ? 'rotate-45' : ''}`}>
                      +
                    </span>
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openFaq === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                    }`}
                  >
                    <div className="p-4 pt-0 text-sm text-gray-600 leading-relaxed">
                      {item.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Satisfaction survey */}
            <div className="mt-8 bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl p-6">
              <h3 className="font-bold text-gray-900 mb-3">🗳️ Оцените работу министерства</h3>
              <div className="flex gap-2">
                {['😡', '😤', '😐', '🙂', '😊'].map((emoji, i) => (
                  <button
                    key={i}
                    className="text-3xl hover:scale-125 transition-transform p-2 rounded-lg hover:bg-white"
                    title={
                      i === 0 ? 'Ужасно' :
                      i === 1 ? 'Плохо' :
                      i === 2 ? 'Терпимо' :
                      i === 3 ? 'Кнопка не работает' :
                      'Кнопка тоже не работает'
                    }
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-400 mt-2">
                * Результаты опроса ни на что не влияют, но нам приятно
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
