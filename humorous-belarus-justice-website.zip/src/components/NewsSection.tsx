const news = [
  {
    date: '28.01.2026',
    category: 'СРОЧНО',
    title: 'В министерстве наконец-то починили принтер на втором этаже',
    excerpt: 'После 8 месяцев ожидания запчасти из Могилёва, принтер HP LaserJet 1020 снова введён в эксплуатацию. Сотрудники ликуют.',
    hot: true,
  },
  {
    date: '25.01.2026',
    category: 'Законодательство',
    title: 'Принят новый закон о дополнении закона о поправках к закону',
    excerpt: 'Законопроект, вносящий изменения в закон о внесении изменений в ранее изменённый закон, одобрен в третьем чтении. Никто не понял, о чём он.',
    hot: false,
  },
  {
    date: '22.01.2026',
    category: 'Достижения',
    title: 'Очередь в окно №3 сократилась до 4 часов',
    excerpt: 'Благодаря внедрению инновационной системы электронной очереди (нового калькулятора), время ожидания сократилось на целых 15 минут.',
    hot: false,
  },
  {
    date: '20.01.2026',
    category: 'Кадры',
    title: 'Объявлен конкурс на замещение должности хранителя печати',
    excerpt: 'Требования: опыт работы с печатями от 15 лет, способность ставить печать идеально ровно с закрытыми глазами, знание 47 видов чернил.',
    hot: false,
  },
  {
    date: '18.01.2026',
    category: 'Инновации',
    title: 'Министерство перешло с Windows XP на Windows 7',
    excerpt: 'В рамках программы цифровой трансформации 2020-2030, все 3 компьютера министерства успешно обновлены. Internet Explorer работает стабильно.',
    hot: true,
  },
  {
    date: '15.01.2026',
    category: 'Международное',
    title: 'Делегация министерства посетила буфет посольства Туркменистана',
    excerpt: 'В ходе рабочего визита были достигнуты договорённости о взаимных поставках канцтоваров. Дегустация плова прошла успешно.',
    hot: false,
  },
];

export default function NewsSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">📰 Новости министерства</h2>
            <p className="text-gray-500 mt-1">Последние события из жизни бюрократии</p>
          </div>
          <button className="hidden md:block px-4 py-2 border-2 border-blue-900 text-blue-900 rounded-lg hover:bg-blue-900 hover:text-white transition-colors text-sm font-medium">
            Все новости →
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.map((item, i) => (
            <article
              key={i}
              className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group cursor-pointer hover:-translate-y-1"
            >
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-gray-400">{item.date}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    item.hot
                      ? 'bg-red-100 text-red-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}>
                    {item.category}
                  </span>
                  {item.hot && <span className="text-xs">🔥</span>}
                </div>
                <h3 className="font-bold text-gray-900 mb-2 group-hover:text-blue-800 transition-colors leading-snug">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {item.excerpt}
                </p>
              </div>
              <div className="px-6 py-3 bg-gray-50 border-t border-gray-100">
                <span className="text-xs text-blue-700 font-medium group-hover:underline">
                  Читать далее (если осилите) →
                </span>
              </div>
            </article>
          ))}
        </div>

        <div className="md:hidden mt-6 text-center">
          <button className="px-6 py-3 border-2 border-blue-900 text-blue-900 rounded-lg hover:bg-blue-900 hover:text-white transition-colors text-sm font-medium">
            Все новости →
          </button>
        </div>
      </div>
    </section>
  );
}
