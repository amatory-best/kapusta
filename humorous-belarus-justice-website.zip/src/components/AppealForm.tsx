import { useState } from 'react';

export default function AppealForm() {
  const [submitted, setSubmitted] = useState(false);
  const [charCount, setCharCount] = useState(0);

  if (submitted) {
    return (
      <section className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="text-6xl mb-4">📬</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Ваше обращение принято!</h2>
          <p className="text-gray-600 mb-2">
            Номер обращения: <span className="font-mono font-bold text-blue-800">БЮР-2026-{Math.floor(Math.random() * 999999)}</span>
          </p>
          <p className="text-sm text-gray-500 mb-6">
            Ожидаемый срок ответа: от 30 до 300 рабочих дней.<br />
            Ваше обращение будет рассмотрено в порядке живой очереди среди 847 293 других обращений.<br />
            Спасибо за ваше терпение. Оно вам ещё пригодится.
          </p>
          <div className="bg-white rounded-xl p-4 shadow-md inline-block">
            <p className="text-sm text-gray-600">
              📊 <strong>Текущее место в очереди:</strong>{' '}
              <span className="text-red-600 font-bold text-lg">847 294</span>
            </p>
          </div>
          <button
            onClick={() => setSubmitted(false)}
            className="block mx-auto mt-6 text-sm text-blue-700 hover:underline"
          >
            Подать ещё одно обращение (бессмысленно, но можно)
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gradient-to-br from-blue-900 to-blue-950 text-white">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold">✉️ Электронное обращение</h2>
          <p className="text-blue-300 mt-2">
            Напишите нам — мы внимательно прочитаем* и обязательно ответим**
          </p>
          <p className="text-xs text-blue-400 mt-1">
            * с вероятностью 12% &nbsp; ** с вероятностью 3%
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-blue-200 mb-2">
                ФИО (полностью, включая отчество прадедушки)
              </label>
              <input
                type="text"
                placeholder="Иванов Иван Иванович Иванов"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-blue-300/50 focus:outline-none focus:border-yellow-400 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-blue-200 mb-2">
                Email (если у вас есть интернет)
              </label>
              <input
                type="email"
                placeholder="grazhdanin@mail.by"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-blue-300/50 focus:outline-none focus:border-yellow-400 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-blue-200 mb-2">
                Тема обращения
              </label>
              <select className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white focus:outline-none focus:border-yellow-400 transition-colors">
                <option value="" className="text-gray-900">Выберите тему...</option>
                <option value="1" className="text-gray-900">Жалоба на работу министерства</option>
                <option value="2" className="text-gray-900">Жалоба на жалобу</option>
                <option value="3" className="text-gray-900">Благодарность (подозрительно)</option>
                <option value="4" className="text-gray-900">Предложение (будет проигнорировано)</option>
                <option value="5" className="text-gray-900">Не знаю, но хочу пожаловаться</option>
                <option value="6" className="text-gray-900">Экзистенциальный кризис</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-blue-200 mb-2">
                Приоритет
              </label>
              <select className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white focus:outline-none focus:border-yellow-400 transition-colors">
                <option value="" className="text-gray-900">Выберите приоритет...</option>
                <option value="1" className="text-gray-900">🟢 Низкий (рассмотрим через год)</option>
                <option value="2" className="text-gray-900">🟡 Средний (рассмотрим через полгода)</option>
                <option value="3" className="text-gray-900">🔴 Высокий (рассмотрим через 3 месяца)</option>
                <option value="4" className="text-gray-900">⚡ Критический (рассмотрим через месяц, может быть)</option>
              </select>
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-blue-200 mb-2">
              Текст обращения (минимум 500 символов, потому что мы любим читать)
            </label>
            <textarea
              rows={5}
              placeholder="Уважаемое министерство! Обращаюсь к вам с глубоким уважением и лёгким отчаянием..."
              className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-blue-300/50 focus:outline-none focus:border-yellow-400 transition-colors resize-none"
              onChange={(e) => setCharCount(e.target.value.length)}
            />
            <div className="flex justify-between mt-1">
              <p className="text-xs text-blue-400">
                {charCount < 500
                  ? `Ещё ${500 - charCount} символов до минимума. Старайтесь!`
                  : '✅ Достаточно букв. Можно отправлять!'}
              </p>
              <span className="text-xs text-blue-400">{charCount}/∞</span>
            </div>
          </div>

          <div className="mt-6 flex items-start gap-3">
            <input type="checkbox" className="mt-1 w-4 h-4 accent-yellow-400" />
            <label className="text-sm text-blue-200">
              Я согласен(а) с тем, что моё обращение может быть использовано в качестве
              развлекательного чтения на корпоративе министерства, перенаправлено в другое
              ведомство или напечатано на оборотной стороне для черновиков
            </label>
          </div>

          <div className="mt-6 flex items-start gap-3">
            <input type="checkbox" className="mt-1 w-4 h-4 accent-yellow-400" />
            <label className="text-sm text-blue-200">
              Подтверждаю, что я не робот (хотя робот, возможно, заполнил бы форму быстрее)
            </label>
          </div>

          <button
            onClick={() => setSubmitted(true)}
            className="mt-8 w-full py-4 bg-gradient-to-r from-red-700 to-red-600 text-white font-bold rounded-lg hover:from-red-800 hover:to-red-700 transition-all shadow-lg hover:shadow-xl text-lg"
          >
            📨 Отправить в бездну бюрократии
          </button>
        </div>
      </div>
    </section>
  );
}
