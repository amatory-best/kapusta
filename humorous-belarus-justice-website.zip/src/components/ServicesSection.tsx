const services = [
  {
    icon: '📝',
    title: 'Регистрация юридических лиц',
    description: 'Подготовьте всего 147 документов, 3 нотариально заверенные копии вашей совести и справку о наличии справки',
    time: '~47 рабочих дней',
    docs: '147 документов',
  },
  {
    icon: '💍',
    title: 'Регистрация актов гражданского состояния (ЗАГС)',
    description: 'Вступите в брак быстро и решительно! Развод — тоже, но с 3 заявлениями и периодом охлаждения до ледникового периода',
    time: '~30 дней',
    docs: '23 документа',
  },
  {
    icon: '📜',
    title: 'Нотариальные услуги',
    description: 'Поставим печать на вашу печать, заверим заверение и удостоверим удостоверение. Рекурсия — наша специализация',
    time: '~5 рабочих дней',
    docs: '∞ копий',
  },
  {
    icon: '🏛️',
    title: 'Адвокатура',
    description: 'Предоставим адвоката, который объяснит, почему вам нужен другой адвокат, который объяснит законы, которые объясняют другие законы',
    time: '~2-3 месяца',
    docs: '89 документов',
  },
  {
    icon: '📚',
    title: 'Правовая экспертиза',
    description: 'Наши эксперты внимательно прочитают ваш документ, покачают головой и попросят переделать. Стандартная процедура',
    time: '~14 рабочих дней',
    docs: '34 документа',
  },
  {
    icon: '🏗️',
    title: 'Принудительное исполнение',
    description: 'Если вас не убедили слова, мы пришлём человека со строгим взглядом и папкой. Обычно помогает',
    time: '~60 рабочих дней',
    docs: '56 документов',
  },
  {
    icon: '📂',
    title: 'Архивное дело',
    description: 'Мы храним ваши документы с 1917 года. Некоторые даже можем найти. За дополнительную плату — в течение месяца',
    time: '~21 день',
    docs: '12 документов',
  },
  {
    icon: '🌍',
    title: 'Апостиль',
    description: 'Поставим волшебный штамп, который превращает белорусскую бумажку в международную бумажку. Магия бюрократии!',
    time: '~7 рабочих дней',
    docs: '15 документов',
  },
];

export default function ServicesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">🏛️ Государственные услуги</h2>
          <p className="text-gray-500 mt-2 max-w-2xl mx-auto">
            Мы оказываем широкий спектр услуг, которые вы не просили, но без которых жить не сможете.
            <br />
            <span className="text-xs italic">* Срок оказания услуг является приблизительным и может отличаться от реального в 2-10 раз</span>
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <div
              key={i}
              className="group relative bg-gradient-to-br from-gray-50 to-white border-2 border-gray-100 rounded-xl p-6 hover:border-blue-300 hover:shadow-xl transition-all duration-300 cursor-pointer"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="font-bold text-gray-900 mb-2 group-hover:text-blue-800 transition-colors text-sm">
                {service.title}
              </h3>
              <p className="text-xs text-gray-500 mb-4 leading-relaxed">
                {service.description}
              </p>
              <div className="flex items-center gap-3 text-[10px] text-gray-400">
                <span className="flex items-center gap-1">
                  ⏱️ {service.time}
                </span>
                <span className="flex items-center gap-1">
                  📄 {service.docs}
                </span>
              </div>

              {/* Hover effect */}
              <div className="absolute inset-0 bg-blue-900/0 group-hover:bg-blue-900/5 rounded-xl transition-colors" />
            </div>
          ))}
        </div>

        {/* Fun counter */}
        <div className="mt-12 bg-gradient-to-r from-blue-900 to-blue-800 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <CounterItem number="1 247 893" label="Документов обработано" sub="(потеряно всего 12)" />
            <CounterItem number="847" label="Печатей поставлено сегодня" sub="(рекорд!)" />
            <CounterItem number="3.5" label="Часа — среднее время в очереди" sub="(улучшение на 2%)" />
            <CounterItem number="∞" label="Справок потребовано" sub="(и это не предел)" />
          </div>
        </div>
      </div>
    </section>
  );
}

function CounterItem({ number, label, sub }: { number: string; label: string; sub: string }) {
  return (
    <div>
      <div className="text-3xl md:text-4xl font-bold text-yellow-400 mb-1">{number}</div>
      <div className="text-sm font-medium">{label}</div>
      <div className="text-xs text-blue-300 mt-1">{sub}</div>
    </div>
  );
}
