import { useState, useEffect } from 'react';

const windows = [
  { id: 1, name: 'Окно №1', status: 'Обед', current: '—', waiting: 0 },
  { id: 2, name: 'Окно №2', status: 'Закрыто навсегда', current: '—', waiting: 0 },
  { id: 3, name: 'Окно №3 (легенда)', status: 'Работает!', current: 'Б-047', waiting: 142 },
  { id: 4, name: 'Окно №4', status: 'Сотрудник в отпуске', current: '—', waiting: 0 },
  { id: 5, name: 'Окно №5', status: 'Технический перерыв', current: '—', waiting: 0 },
  { id: 6, name: 'Окно №6', status: 'Никто не знает', current: '?', waiting: '?' as unknown as number },
];

export default function QueueWidget() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-16 bg-gradient-to-br from-gray-100 to-blue-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900">🎫 Электронная очередь</h2>
          <p className="text-gray-500 mt-1">Мониторинг в реальном времени*</p>
          <p className="text-xs text-gray-400">* реальность может отличаться от мониторинга</p>
        </div>

        {/* Clock */}
        <div className="text-center mb-8">
          <div className="inline-block bg-gray-900 text-green-400 font-mono text-4xl px-8 py-4 rounded-xl shadow-lg">
            {time.toLocaleTimeString('ru-RU')}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Время минское. Совпадение с реальным — случайность.
          </p>
        </div>

        {/* Queue board */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {windows.map((w) => (
            <div
              key={w.id}
              className={`rounded-xl p-5 border-2 transition-all ${
                w.status === 'Работает!'
                  ? 'bg-green-50 border-green-300 shadow-lg shadow-green-100'
                  : 'bg-white border-gray-200 opacity-70'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900">{w.name}</h3>
                <span
                  className={`text-xs px-2 py-1 rounded-full font-medium ${
                    w.status === 'Работает!'
                      ? 'bg-green-200 text-green-800'
                      : 'bg-red-100 text-red-600'
                  }`}
                >
                  {w.status}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div>
                  <span className="text-gray-500">Текущий: </span>
                  <span className="font-mono font-bold text-lg">{w.current}</span>
                </div>
                <div>
                  <span className="text-gray-500">В очереди: </span>
                  <span className={`font-bold text-lg ${
                    typeof w.waiting === 'number' && w.waiting > 100 ? 'text-red-600' : ''
                  }`}>
                    {w.waiting}
                  </span>
                </div>
              </div>
              {w.status === 'Работает!' && (
                <div className="mt-3 bg-green-100 rounded-lg p-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-xs text-green-700">
                      Среднее ожидание: ~4 часа 23 минуты
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Tips */}
        <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h3 className="font-bold text-yellow-900 mb-3">💡 Советы бывалого посетителя:</h3>
          <ul className="grid md:grid-cols-2 gap-2 text-sm text-yellow-800">
            <li className="flex items-start gap-2">
              <span>1️⃣</span>
              <span>Берите с собой еду и воду — никто не знает, когда вы выйдете</span>
            </li>
            <li className="flex items-start gap-2">
              <span>2️⃣</span>
              <span>Зарядите телефон на 100% — Wi-Fi здесь не работает</span>
            </li>
            <li className="flex items-start gap-2">
              <span>3️⃣</span>
              <span>Возьмите книгу. Лучше — собрание сочинений. Толстого.</span>
            </li>
            <li className="flex items-start gap-2">
              <span>4️⃣</span>
              <span>Подружитесь с соседями по очереди — это ваша новая семья</span>
            </li>
            <li className="flex items-start gap-2">
              <span>5️⃣</span>
              <span>Окно №3 — единственное работающее. Привыкайте.</span>
            </li>
            <li className="flex items-start gap-2">
              <span>6️⃣</span>
              <span>«Я только спросить» — не работает с 1994 года</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
