import { useState } from 'react';

const navItems = [
  'О министерстве',
  'Деятельность',
  'Документы',
  'Услуги*',
  'Обращения**',
  'Контакты***',
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState('');

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setSearchResult('По вашему запросу найдено 0 результатов. Попробуйте обратиться лично с заявлением в 3-х экземплярах.');
    }
  };

  return (
    <header className="relative z-50">
      {/* Top bar */}
      <div className="bg-gradient-to-r from-red-800 via-red-700 to-green-800 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span>🇧🇾 Республика Беларусь</span>
            <span className="hidden sm:inline opacity-70">|</span>
            <span className="hidden sm:inline opacity-70">Версия для слабовидящих чиновников</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="hover:underline">РУС</button>
            <span>|</span>
            <button className="hover:underline opacity-50 cursor-not-allowed" title="Переводчик в отпуске">БЕЛ</button>
            <span>|</span>
            <button className="hover:underline opacity-50 cursor-not-allowed" title="We don't speak English here">ENG</button>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="bg-white shadow-lg border-b-4 border-red-700">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Coat of arms */}
              <div className="w-16 h-16 flex items-center justify-center text-4xl" title="Герб нарисован в Paint">
                ⚖️
              </div>
              <div>
                <h1 className="text-lg md:text-xl font-bold text-gray-900 leading-tight">
                  МИНИСТЕРСТВО ЮСТИЦИИ
                </h1>
                <p className="text-sm text-gray-600">Республики Беларусь</p>
                <p className="text-[10px] text-gray-400 italic">*сайт работает по расписанию: Пн-Пт 9:00-17:00, обед 13:00-14:00</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                title="Поиск (результаты не гарантируются)"
              >
                🔍
              </button>
              {/* Mobile menu */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                {menuOpen ? '✕' : '☰'}
              </button>
            </div>
          </div>

          {/* Search bar */}
          {searchOpen && (
            <div className="mt-4 animate-fade-in">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setSearchResult(''); }}
                  placeholder="Введите запрос (надежда умирает последней)..."
                  className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-red-700 focus:outline-none text-sm"
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <button
                  onClick={handleSearch}
                  className="px-6 py-2 bg-red-700 text-white rounded-lg hover:bg-red-800 transition-colors text-sm font-medium"
                >
                  Найти
                </button>
              </div>
              {searchResult && (
                <p className="mt-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
                  {searchResult}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className={`bg-gradient-to-r from-blue-900 to-blue-800 ${menuOpen ? 'block' : 'hidden'} lg:block`}>
          <div className="max-w-7xl mx-auto px-4">
            <ul className="flex flex-col lg:flex-row">
              {navItems.map((item) => (
                <li key={item}>
                  <button className="w-full lg:w-auto px-4 py-3 text-white text-sm font-medium hover:bg-blue-700 transition-colors text-left lg:text-center border-b lg:border-b-0 border-blue-700 last:border-b-0">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </nav>
      </div>
    </header>
  );
}
