export default function MinisterSection() {
  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          {/* Photo */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/images/minister.jpg"
                alt="Министр за работой"
                className="w-full h-[400px] object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 bg-white rounded-xl shadow-lg p-3 text-sm">
              <span className="text-gray-500">Статус:</span>
              <span className="ml-2 text-green-600 font-medium">● На совещании</span>
              <p className="text-[10px] text-gray-400 mt-1">
                (на совещании с 2003 года)
              </p>
            </div>
            <div className="absolute -top-3 -left-3 bg-red-700 text-white px-3 py-1 rounded-lg text-xs font-bold shadow-lg rotate-[-3deg]">
              ФОТО ДНЯ
            </div>
          </div>

          {/* Info */}
          <div>
            <span className="text-xs text-blue-700 font-bold uppercase tracking-wider">Руководство</span>
            <h2 className="text-3xl font-bold text-gray-900 mt-2 mb-4">
              Слово министра
            </h2>
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-red-700 mb-6">
              <p className="text-gray-700 leading-relaxed italic">
                «Дорогие граждане! Министерство юстиции работает для вас 24/7*.
                Мы стремимся сделать каждое ваше обращение незабываемым опытом.
                Наша цель — чтобы ни одна бумажка не осталась без печати,
                ни одна справка — без копии, и ни один гражданин — без очереди.
                Вместе мы сила! Особенно в очереди в окно №3.»
              </p>
              <p className="text-xs text-gray-400 mt-3">
                * Режим 24/7 означает: 24 минуты работы, 7 часов перерыв
              </p>
            </div>

            <div className="space-y-3">
              <ScheduleItem day="Понедельник" time="Совещание о прошлых совещаниях" />
              <ScheduleItem day="Вторник" time="Планёрка о планёрках" />
              <ScheduleItem day="Среда" time="Приём граждан (теоретически)" />
              <ScheduleItem day="Четверг" time="Подписание бумаг о подписании бумаг" />
              <ScheduleItem day="Пятница" time="Инвентаризация печатей" />
            </div>

            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
              <p className="text-sm text-yellow-800">
                📞 <strong>Горячая линия:</strong> +375 (17) 200-00-00
              </p>
              <p className="text-xs text-yellow-600 mt-1">
                Линия горячая, но трубку берут холодно. Среднее время ожидания: 45 мин.
                Для ускорения нажмите 1, затем 3, затем 7, затем повесьте трубку и придите лично.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ScheduleItem({ day, time }: { day: string; time: string }) {
  return (
    <div className="flex items-center gap-3 text-sm">
      <span className="w-28 font-medium text-gray-700">{day}</span>
      <span className="flex-1 text-gray-500 border-b border-dashed border-gray-200 pb-1">{time}</span>
    </div>
  );
}
