export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1 */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">⚖️</span>
              <div>
                <h3 className="text-white font-bold text-sm">МИНЮСТ РБ</h3>
                <p className="text-xs text-gray-500">Сила в бумажках</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed">
              Министерство юстиции Республики Беларусь — ваш надёжный партнёр в мире
              непонятных законов и бесконечных справок с 1917 года.
            </p>
          </div>

          {/* Column 2 */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4">Полезные ссылки*</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Где я?</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Зачем я здесь?</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Куда идти дальше?</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Реестр печатей</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Жалобная книга (том 47)</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Карта очередей в реальном времени</a></li>
            </ul>
            <p className="text-[10px] text-gray-600 mt-2">* Полезность не гарантируется</p>
          </div>

          {/* Column 3 */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4">Контакты</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <span>📍</span>
                <span>220004, г. Минск, ул. Собинова, 10 (3-й подъезд, 7-й этаж, кабинет за шкафом)</span>
              </li>
              <li className="flex items-start gap-2">
                <span>📞</span>
                <span>+375 (17) 200-00-00 (гудки бесплатно)</span>
              </li>
              <li className="flex items-start gap-2">
                <span>📠</span>
                <span>+375 (17) 200-00-01 (факс — наш основной канал связи)</span>
              </li>
              <li className="flex items-start gap-2">
                <span>📧</span>
                <span>kanc@minjust.gov.by (проверяем раз в квартал)</span>
              </li>
            </ul>
          </div>

          {/* Column 4 */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4">Режим работы</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Пн-Чт</span>
                <span>9:00 — 17:00</span>
              </div>
              <div className="flex justify-between">
                <span>Пятница</span>
                <span>9:00 — 15:45</span>
              </div>
              <div className="flex justify-between">
                <span>Обед</span>
                <span>13:00 — 14:00</span>
              </div>
              <div className="flex justify-between text-red-400">
                <span>Сб-Вс</span>
                <span>Мы отдыхаем</span>
              </div>
            </div>
            <div className="mt-4 p-3 bg-gray-800 rounded-lg">
              <p className="text-xs text-gray-500">
                ⚠️ В период дождей, снегопадов, солнечной активности, магнитных бурь
                и по настроению — режим работы может меняться без предупреждения
              </p>
            </div>

            <div className="mt-4 flex gap-3">
              <SocialBtn emoji="📘" label="VK" />
              <SocialBtn emoji="📱" label="Telegram" />
              <SocialBtn emoji="📷" label="Instagram*" />
            </div>
            <p className="text-[10px] text-gray-600 mt-1">* Признан экстремистским (шутка)</p>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
            <p>
              © 2026 Министерство юстиции Республики Беларусь. Все права защищены.
              Некоторые обязанности — тоже.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="hover:text-white transition-colors">Политика конфиденциальности (LOL)</a>
              <span>|</span>
              <a href="#" className="hover:text-white transition-colors">Карта сайта</a>
              <span>|</span>
              <span className="text-gray-600">Сайт создан в Paint за 3 совещания</span>
            </div>
          </div>
          <div className="text-center mt-3">
            <p className="text-[10px] text-gray-700">
              Сайт оптимизирован для Internet Explorer 6. Для Firefox и Chrome обратитесь в окно №3 с заявлением в 3-х экземплярах.
              <br />
              При копировании материалов ссылка на сайт обязательна. Хотя зачем вам копировать это — загадка.
            </p>
          </div>
        </div>
      </div>

      {/* Easter egg visitor counter */}
      <div className="bg-black py-2 text-center">
        <p className="text-xs text-gray-700 font-mono">
          👁️ Вы посетитель №{Math.floor(Math.random() * 100) + 47} за всю историю сайта &nbsp;|&nbsp;
          Последнее обновление: вчера (или позавчера, кто считает)
        </p>
      </div>
    </footer>
  );
}

function SocialBtn({ emoji, label }: { emoji: string; label: string }) {
  return (
    <button
      className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
      title={label}
    >
      <span className="text-lg">{emoji}</span>
    </button>
  );
}
