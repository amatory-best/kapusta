import { useState, useEffect } from 'react';

const slides = [
  {
    title: 'Справедливость — наше всё!',
    subtitle: 'А если не наше, то мы разберёмся, чьё',
    badge: '⚡ ВАЖНО',
  },
  {
    title: 'Регистрация юридических лиц',
    subtitle: 'Всего за 47 рабочих дней* (*при благоприятном расположении звёзд)',
    badge: '📋 УСЛУГИ',
  },
  {
    title: 'Электронное правительство',
    subtitle: 'Факс работает с 9:00 до 17:00',
    badge: '💻 ЦИФРОВИЗАЦИЯ',
  },
];

export default function HeroBanner() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative h-[420px] md:h-[480px] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Здание министерства"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 via-blue-900/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
        <div className="max-w-2xl">
          <span className="inline-block px-3 py-1 bg-red-700 text-white text-xs font-bold rounded-full mb-4 animate-pulse">
            {slides[current].badge}
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 leading-tight transition-all duration-500">
            {slides[current].title}
          </h2>
          <p className="text-lg md:text-xl text-blue-200 mb-8">
            {slides[current].subtitle}
          </p>
          <div className="flex gap-4 flex-wrap">
            <button className="px-6 py-3 bg-red-700 text-white font-medium rounded-lg hover:bg-red-800 transition-all hover:scale-105 shadow-lg">
              Записаться на приём
            </button>
            <button className="px-6 py-3 bg-white/10 backdrop-blur-sm text-white font-medium rounded-lg hover:bg-white/20 transition-all border border-white/30">
              Подать жалобу на жалобу
            </button>
          </div>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`w-3 h-3 rounded-full transition-all ${
              i === current ? 'bg-white w-8' : 'bg-white/50'
            }`}
          />
        ))}
      </div>

      {/* Running ticker */}
      <div className="absolute bottom-0 left-0 right-0 bg-red-800/90 text-white py-2 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap text-sm">
          ⚠️ ВНИМАНИЕ: Приём граждан временно приостановлен в связи с обеденным перерывом (с 2019 года) &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
          📢 Новый порядок подачи документов: теперь нужно 48 копий вместо 47 &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
          🏆 Минюст признан самым загадочным министерством по версии граждан &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
          📎 Скрепка — лучший друг юриста &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
          ☕ Кофемашина на 3-м этаже снова работает! &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
        </div>
      </div>
    </section>
  );
}
