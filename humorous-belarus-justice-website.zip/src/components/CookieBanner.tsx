import { useState } from 'react';

export default function CookieBanner() {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 animate-slide-up">
      <div className="max-w-4xl mx-auto bg-gray-900 text-white rounded-2xl p-6 shadow-2xl border border-gray-700">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="text-4xl">🍪</div>
          <div className="flex-1">
            <h3 className="font-bold text-lg">Мы используем cookies!</h3>
            <p className="text-sm text-gray-300 mt-1">
              А также печеньки, скрепки, степлеры и синие ручки. Продолжая пользоваться сайтом,
              вы соглашаетесь на обработку ваших персональных данных, передачу их в архив
              и хранение до тепловой смерти Вселенной. Отказ невозможен — как и от бюрократии.
            </p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => setVisible(false)}
              className="px-5 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors"
            >
              Принять судьбу
            </button>
            <button
              onClick={() => setVisible(false)}
              className="px-5 py-2 bg-gray-700 text-white text-sm font-medium rounded-lg hover:bg-gray-600 transition-colors"
              title="Эта кнопка тоже принимает"
            >
              Отказаться*
            </button>
          </div>
        </div>
        <p className="text-[10px] text-gray-600 mt-2">
          * Кнопка «Отказаться» создана для психологического комфорта и не имеет реального функционала
        </p>
      </div>
    </div>
  );
}
